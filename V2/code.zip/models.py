import loadModels
import torch
from tqdm import tqdm
import torchvision.transforms as transforms
from image_utils import imagesToTensor ,pathsToTensor , pathToTensor , imageToTensor , tensorToImage 
loss_criterion = torch.nn.functional.mse_loss
from torch.utils.data import DataLoader, Dataset
import os
from datasets import load_dataset
import pickle
import optax
from torch import autocast
from diffusers.loaders import AttnProcsLayers
from diffusers.models.attention_processor import LoRAAttnProcessor

from diffusers.optimization import get_scheduler
from peft import LoraConfig , LoraModel
import re
class modelDataSet(Dataset):
    def __init__(self):
        self.image_files = [file for file in os.listdir("/content/pickle_images") ]

    def __len__(self):
        return len(self.image_files)
    def __getitem__(self, idx):
      file_name = self.image_files[idx]

      return file_name
    

class Diffusion():
    def __init__(self ,device,schedulerType = "LMSD" ):
        self.device = device
        tokenizer , text_encoder = loadModels.getClip(device)
        self.tokenizer = tokenizer
        self.text_encoder = text_encoder
        self.scheduler = loadModels.getScheduler(schedulerType)
        self.vae = loadModels.getVae(device)
        self.unet = loadModels.getUnet(device)
        self.schedulerType = schedulerType
        tokenizerMBart50 , text_generater = loadModels.getMBart50(device)
        self.tokenizerMBart50 = tokenizerMBart50
        self.text_generater = text_generater
        self.simpson_params = loadModels.getSimpson()
        self.bender_params = loadModels.getBender()
        self.addLora()
        self.dataset_ = "None"

    def test_vae(self , image_path):
        ff = imageToTensor(image_path).unsqueeze(0).to(self.device)
        image_embedding = self.vae.encode(ff).latent_dist.sample()*0.18215
        with torch.no_grad():
            images = self.vae.decode(image_embedding*(1/self.vae.config.scaling_factor)).sample
        return tensorToImage(images)

    def translateArToEn(self, prompt):
        encoded_ar = self.tokenizerMBart50(prompt, return_tensors="pt")
        encoded_ar.to(self.device)
        generated_tokens = self.text_generater.generate(
            **encoded_ar,
            forced_bos_token_id= self.tokenizerMBart50.lang_code_to_id["en_XX"]
        )
        enPrompt = self.tokenizerMBart50.batch_decode(generated_tokens, skip_special_tokens=True)[0]
        print(enPrompt)
        return enPrompt

    def detect_language(self,text):
        arabic_pattern = re.compile(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]+')  # Arabic Unicode range
        if arabic_pattern.search(text):
            return 'ar'  
        else:
            return 'en' 

    def labelsToTensor(self, labels):
        text_input = self.tokenizer(labels, padding="max_length", max_length=77, truncation=True, return_tensors="pt")
        with torch.no_grad():
            text_embeddings = self.text_encoder(text_input.input_ids.to(self.device))[0]
        max_length = text_input.input_ids.shape[-1]
        uncond_input = self.tokenizer(
        [""] *  text_embeddings.shape[0], padding="max_length", max_length=max_length,truncation=True, return_tensors="pt"
        )
        with torch.no_grad():
            uncond_embeddings = self.text_encoder(uncond_input.input_ids.to(self.device))[0]
        text_embeddings = torch.cat([uncond_embeddings, text_embeddings])

        return text_embeddings


    def labelsToTensorWithoutEmptyStr(self, labels):
        text_input = self.tokenizer(labels, padding="max_length", max_length=77, truncation=True, return_tensors="pt")
        with torch.no_grad():
            text_embeddings = self.text_encoder(text_input.input_ids.to(self.device))[0]
        return text_embeddings



    def generate(self ,prompts , scale_guide=7.5 , timesteps = 50,seed = 5 ,dataset_ = "None", resolution=(512,512)):
        generator = torch.manual_seed(seed)
        if(seed == 0):
            generator = torch.manual_seed(torch.seed())

        if(dataset_ =="Simpson"):
            self.loadSimpson()
        elif(dataset_ =="Bender"):
            self.loadBender()
        else:
            self.addLora()
            
        samples = len(prompts)
        prompt = prompts[0]
        if(self.detect_language(prompts[0])=="ar"):
            prompt = self.translateArToEn(prompt)
            prompts = [prompt]*samples
        images_ = []
        self.scheduler = loadModels.getScheduler( self.schedulerType)
        try:
            self.vae
        except AttributeError:
                self.vae = loadModels.getVae(self.device)
                tokenizer , text_encoder = loadModels.getClip(self.device)
                self.tokenizer = tokenizer
                self.text_encoder = text_encoder
        labelsT = self.labelsToTensor(prompts).to(self.device)
        latent = torch.randn(
            (samples, 4, resolution[0] // 8, resolution[1] // 8),
              generator=generator,
            )
        self.scheduler.set_timesteps(timesteps)

        latent = latent.to(self.device)
        latent = latent * self.scheduler.sigmas[0] # Need to scale to match k
        with autocast("cuda"):
            for i, t in tqdm(enumerate(self.scheduler.timesteps)):
                t = t.to(self.device)
                latent_model_input = torch.cat([latent] * 2)
                sigma = self.scheduler.sigmas[i]
                latent_model_input = latent_model_input / ((sigma**2 + 1) ** 0.5)
                with torch.no_grad():
                    residual = self.unet(latent_model_input, t, labelsT ) 

                noise_pred_uncond, noise_pred_text = residual.chunk(2)
                noise_pred = noise_pred_uncond + scale_guide * (noise_pred_text - noise_pred_uncond)

                latent = self.scheduler.step(noise_pred, t, latent).prev_sample
        latent = 1 / 0.18215 * latent
        with torch.no_grad():
            images = self.vae.decode(latent).sample
        for i in range(samples):
            images_.append(tensorToImage(images[i]))
        return images_ , prompt
    
    def trainBatch(self , image_embedding , text_embedding , opt,lr_scheduler ):
        noise = torch.randn_like(image_embedding)
        timesteps = torch.randint(0, 1000, (image_embedding.shape[0],) , device = self.device).long()
        noisy_x = self.scheduler.add_noise(image_embedding, noise, timesteps)
        del image_embedding
        pred = self.unet(noisy_x, timesteps, text_embedding)
        del text_embedding, noisy_x
        loss = loss_criterion(pred.float(), noise.float(), reduction="mean")
        del  noise, timesteps, pred
        loss.backward()
        opt.step()
        lr_scheduler.step()
        opt.zero_grad()
        lossV = loss.item()
        del loss
        return lossV
    def addLora(self):
        unet_lora_config = LoraConfig(
            r=128,
            lora_alpha=128,
            init_lora_weights="gaussian",
            target_modules=["to_k", "to_q", "to_v", "to_out.0"],
        )
        self.unet.model.peft_config = {}
        self.unet.model.add_adapter(unet_lora_config)
    
    def loadSimpson(self):
        self.unet.model.load_state_dict(self.simpson_params, strict=False)
    def loadBender(self):
        self.unet.model.load_state_dict(self.bender_params, strict=False)

    def train(self ,custom_dataset_source , createPickle = True ,learning_rate =3e-04 ,batch_size=4,epochs=50 ):
        self.scheduler = loadModels.getScheduler("DDPM")
        save_dir = "/content/pickle_images/"
        os.makedirs(save_dir, exist_ok=True)
        i = 0
        data_loader_source = DataLoader(custom_dataset_source, batch_size=1, shuffle=True, num_workers=2)
        if(createPickle):
            for images ,text in data_loader_source:
                images= images.to(self.device)
                image_embedding = self.vae.encode(images).latent_dist.sample()*0.18215
                text_embedding = self.labelsToTensorWithoutEmptyStr(text).to(self.device)

                file_path = save_dir + str(i) +".pickle"
                i+=1
                data = {"emp" : image_embedding , "con" : text_embedding}
                with open(file_path, 'wb') as file:
                    pickle.dump(data, file)
            del images , text_embedding
        try:
            self.vae
            del self.vae  , self.text_encoder , self.tokenizer
        except AttributeError:
            pass
        custom_dataset = modelDataSet()
        
        data_loader = DataLoader(custom_dataset, batch_size=batch_size, shuffle=True, num_workers=2)


        lora_layers = filter(lambda p: p.requires_grad, self.unet.model.parameters())

        opt = torch.optim.AdamW(lora_layers, lr=learning_rate , betas=(0.9,0.999) , weight_decay=1e-2 , eps=1e-08)
        
        lr_scheduler = get_scheduler(
            "constant",
            optimizer=opt,
            num_warmup_steps=0,
            num_training_steps=epochs *len(data_loader) ,
        )

        for epoch in range(epochs):
            errorC = 0.0
            for filepaths in data_loader:
                image_embedding = []
                text_embedding = []
                for file_name in filepaths:
                    file_path = os.path.join("/content/pickle_images", file_name )
                    with open(file_path, 'rb') as file:
                        data = pickle.load(file)
                    emp = data.get("emp")[0]
                    con = data.get("con")[0]
                    image_embedding.append(emp)
                    text_embedding.append(con)
                image_embedding = torch.stack(image_embedding)
                text_embedding = torch.stack(text_embedding)
                loss = self.trainBatch(image_embedding , text_embedding , opt ,lr_scheduler)
                errorC = errorC + loss
            print("epoch " + str(epoch) + " loss " + str(errorC / len(data_loader)))
               
        del opt
        if(epochs == 1):
            return errorC / len(data_loader)
    def savePoint(self):
        torch.save(self.unet.state_dict(), 'prior.pth')