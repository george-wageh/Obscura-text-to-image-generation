from diffusers import  AutoencoderKL
from transformers import CLIPTokenizer, CLIPTextModel
import gdown
import torch
import os
import torch.nn as nn
from diffusers import  LMSDiscreteScheduler , UNet2DConditionModel , DDPMScheduler , DDIMScheduler , PNDMScheduler , DEISMultistepScheduler 
from peft import LoraConfig

from transformers import MBartForConditionalGeneration, MBart50TokenizerFast




def getVae(device):
    vae = AutoencoderKL(
        sample_size = 512,
        in_channels = 3 ,
        out_channels = 3 ,
        latent_channels= 4,
        down_block_types =("DownEncoderBlock2D" , "DownEncoderBlock2D" , "DownEncoderBlock2D" , "DownEncoderBlock2D"),
        up_block_types = ('UpDecoderBlock2D', 'UpDecoderBlock2D', 'UpDecoderBlock2D', 'UpDecoderBlock2D'),
        block_out_channels =(128, 256, 512, 512),
        layers_per_block = 2,
        scaling_factor= 0.18215,
        norm_num_groups= 32,
    )
    destination_path = "/content/autoencoder.pth"
    if not os.path.exists(destination_path):
        url = "https://drive.google.com/uc?id=1LJ_ie6qoieY150orcUECgxi__5DwMCCF"
        print("Downloading autoencoder.pth...")
        gdown.download(url, output=destination_path, quiet=False)
    vae.load_state_dict(torch.load(destination_path))
    vae.to(device)
    return vae

def getClip(device):
    tokenizer = CLIPTokenizer.from_pretrained("openai/clip-vit-large-patch14")
    text_encoder = CLIPTextModel.from_pretrained("openai/clip-vit-large-patch14").to(device)
    return tokenizer , text_encoder

def getMBart50(device):
    text_generater= MBartForConditionalGeneration.from_pretrained("facebook/mbart-large-50-many-to-many-mmt").to(device)
    tokenizer = MBart50TokenizerFast.from_pretrained("facebook/mbart-large-50-many-to-many-mmt")
    tokenizer.src_lang = "ar_AR"
    return tokenizer , text_generater

class Unet(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.model = UNet2DConditionModel(
            sample_size=64,
            in_channels=4,
            out_channels=4,
            layers_per_block=2,
            block_out_channels=(320, 640, 1280 ,1280 ), 
            down_block_types=(
                "CrossAttnDownBlock2D",  
                "CrossAttnDownBlock2D", 
                "CrossAttnDownBlock2D",  
                "DownBlock2D"
            ),
            mid_block_type='UNetMidBlock2DCrossAttn',
            up_block_types=(
                "UpBlock2D",
                "CrossAttnUpBlock2D",  
                "CrossAttnUpBlock2D",
                "CrossAttnUpBlock2D"
            ),
            cross_attention_dim = 768,
            norm_eps = 1e-05,
            norm_num_groups = 32,
            act_fn = "silu",
            mid_block_scale_factor = 1,
            downsample_padding = 1,
        )

    def forward(self, x, t, label):
        unet_output = self.model(x, t ,encoder_hidden_states=label).sample
        return unet_output
    

def getSimpson():
    destination_path = "/content/simpson.pth"
    if not os.path.exists(destination_path):
        url = "https://drive.google.com/uc?id=1b1uh4ZeKSBgOEmWqHGbl94SS72_TssGl"
        print("Downloading simpson.pth...")
        gdown.download(url, output=destination_path, quiet=False)
    return torch.load(destination_path)

def getBender():
    destination_path = "/content/bender.pth" 
    if not os.path.exists(destination_path):
        url = "https://drive.google.com/uc?id=1nmdmLGGE717SRKcRZvpYlNs8Ap5hshxE"
        print("Downloading bender.pth...")
        gdown.download(url, output=destination_path, quiet=False)
    return torch.load(destination_path)

def getUnet(device):
    unet = Unet()
    destination_path = "/content/prior.pth"  
    if not os.path.exists(destination_path):
        url = "https://drive.google.com/uc?id=1dtcGKf7k0Pg7fDfBvUm22-Eq0241gfQ3"
        print("Downloading prior_model.pth...")
        gdown.download(url, output=destination_path, quiet=False)
    # Load the model
    unet.load_state_dict(torch.load(destination_path))
    unet.to(device)
    return unet


def getScheduler(type_ = "LMSD"):
    noise_scheduler = DDPMScheduler()
    if(type_ == "DDPM"):
        noise_scheduler = DDPMScheduler(num_train_timesteps=1000, beta_start=0.00085, beta_end=0.012, beta_schedule='scaled_linear')
    elif(type_ =="DDIM"):
        noise_scheduler = DDIMScheduler(num_train_timesteps=1000, beta_start=0.00085, beta_end=0.012, beta_schedule='scaled_linear')
    elif(type_ =="PNDM"):
        noise_scheduler = PNDMScheduler(num_train_timesteps=1000, beta_start=0.00085, beta_end=0.012, beta_schedule='scaled_linear')
    elif(type_ =="LMSD"):
        noise_scheduler = LMSDiscreteScheduler(num_train_timesteps=1000, beta_start=0.00085, beta_end=0.012, beta_schedule='scaled_linear')
    elif(type_ =="DEIS"):
        noise_scheduler = DEISMultistepScheduler(num_train_timesteps=1000, beta_start=0.00085, beta_end=0.012, beta_schedule='scaled_linear' )
    return noise_scheduler