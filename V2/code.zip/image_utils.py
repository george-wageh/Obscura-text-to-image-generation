import torchvision.transforms as transforms
from PIL import Image
import torch
def tensorToImage(tensor_):
    denormalized_x = (tensor_.detach() / 2 + 0.5).clamp(0, 1)
    pil = transforms.ToPILImage()(denormalized_x)
    return pil


image_transforms = transforms.Compose([
    transforms.RandomResizedCrop(512, scale=(0.8, 1.0)),  # Adjust size and scale as needed
    transforms.ToTensor(),
])
def imageToTensor(image):
  image = image.convert('RGB')
  image = image_transforms(image)
  return image

def pathToTensor(path):
  image = Image.open(path).convert('RGB')
  image = image_transforms(image)
  return image

def pathsToTensor(filepaths):
    tensor_ = []
    for file_name in filepaths:
       tensor_.append(pathToTensor(file_name))
    return torch.stack(tensor_)

def imagesToTensor(images):
    tensor_ = []
    for image in images:
       tensor_.append(imageToTensor(image))
    return torch.stack(tensor_)

