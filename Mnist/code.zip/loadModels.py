from transformers import CLIPTokenizer, CLIPTextModel
import torch.nn as nn
from diffusers import  LMSDiscreteScheduler , UNet2DConditionModel , DDPMScheduler , DDIMScheduler , PNDMScheduler , DEISMultistepScheduler 
import gdown
import torch
import os

class Unet(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.model = UNet2DConditionModel(
            sample_size=64,
            in_channels=1,
            out_channels=1,
            layers_per_block=2,
            block_out_channels=(64, 64, 64, 64), 
            down_block_types=(
                "CrossAttnDownBlock2D",  
                "CrossAttnDownBlock2D", 
                "CrossAttnDownBlock2D", 
                "DownBlock2D"
            ),
            mid_block_type='UNetMidBlock2DCrossAttn',
            up_block_types=(
                "UpBlock2D",
                "CrossAttnUpBlock2D",
                "CrossAttnUpBlock2D",
                "CrossAttnUpBlock2D"
            ),
            cross_attention_dim = 10,
            norm_eps = 1e-05,
            norm_num_groups = 32,
            act_fn = "silu",
            mid_block_scale_factor = 1,
            downsample_padding = 1,
        )

    def forward(self, x, t, label):
        unet_output = self.model(x, t ,encoder_hidden_states=label).sample
        return unet_output

def getUnet(device):
    unet = Unet()
    destination_path = "/content/unet_mnist.pth"  
    if not os.path.exists(destination_path):
        url = "https://drive.google.com/uc?id=1aEi9BkDzxju6wwrKinYGgT-TIpM6s6Bt"
        print("Downloading unet_mnist.pth...")
        gdown.download(url, output=destination_path, quiet=False)
    # Load the model
    unet.load_state_dict(torch.load(destination_path))
    unet.to(device)
    return unet


def getScheduler():
    return DDPMScheduler(num_train_timesteps=1000)
