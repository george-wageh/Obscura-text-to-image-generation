import loadModels
import torch
from tqdm import tqdm
import torchvision.transforms as transforms
from image_utils import imageToTensor , tensorToImage 
loss_criterion = torch.nn.functional.mse_loss
from torch.utils.data import DataLoader, Dataset
import os
from PIL import Image
from torch import autocast
import random
import wandb
from diffusers.optimization import get_cosine_schedule_with_warmup

class modelDataSet(Dataset):
    def __init__(self):
        self.image_files = [file for file in os.listdir("/content/pickle_images") ]

    def __len__(self):
        return len(self.image_files)
    def __getitem__(self, idx):
      file_name = self.image_files[idx]

      return file_name
    

class Diffusion():
    def __init__(self ,device):
        self.device = device
        self.scheduler = loadModels.getScheduler()
        self.unet = loadModels.getUnet(device)

    def generate(self ,Number = 0):
        num = Number
        if(isinstance(num, int)==False):
            return  Image.new('RGB', (32, 32))
        images = []
        labels = []
        num = int(num)
        while num != 0:
            mod = int(num % 10)
            arrZeros = [0 , 0 , 0 , 0, 0 , 0 , 0 , 0 , 0 , 0  ]
            arrZeros[mod] = 1
            labels.append(arrZeros)
            num = int(num //10)
        labels.reverse()
        label = torch.tensor(labels)
        label = label.unsqueeze(1)
        label = label.to(torch.float32)
        label = label.to(self.device)
        latent = torch.randn(
        (len(labels), 1, 32, 32)
        )
        self.scheduler.set_timesteps(50)
        latent = latent.to(self.device)
        with autocast("cuda"):
            for i, t in tqdm(enumerate(self.scheduler.timesteps)):
                t = t.to(self.device)
                latent_model_input = latent
                latent_model_input = self.scheduler.scale_model_input(latent_model_input , t)

                with torch.no_grad():
                    residual = self.unet(latent_model_input, t, label )

                latent = self.scheduler.step(residual, t, latent).prev_sample
        total_width = 0
        max_height = 0
        for i in range(len(labels)):
            img = tensorToImage(latent[i])
            images.append(img)
            total_width += img.width
            if img.height > max_height:
                max_height = img.height
        new_image = Image.new('RGB', (total_width, max_height))
        x_offset = 0

        for img in images:
            new_image.paste(img, (x_offset, 0))
            x_offset += img.width
        return new_image
    
    def trainBatch(self , image_embedding , label , opt,lr_scheduler ):
        noise = torch.randn_like(image_embedding)
        timesteps = torch.randint(0, 1000, (image_embedding.shape[0],) , device = self.device).long()
        noisy_x = self.scheduler.add_noise(image_embedding, noise, timesteps)
        del image_embedding
        label = label.unsqueeze(1)
        label = label.to(torch.float32)
        label = label.to(self.device)
        pred = self.unet(noisy_x, timesteps, label)
        del label, noisy_x
        loss = loss_criterion(pred.float(), noise.float(), reduction="mean")
        del  noise, timesteps, pred
        loss.backward()
        opt.step()
        lr_scheduler.step()
        opt.zero_grad()
        lossV = loss.item()
        del loss
        return lossV


    def train(self ,custom_dataset_source ,use_wandb = False,generateAfterEpoch=10, learning_rate =1e-04 ,batch_size=10,epochs=30 ):
        self.scheduler.set_timesteps(1000)
        
        data_loader = DataLoader(custom_dataset_source, batch_size=batch_size, shuffle=True, num_workers=2)

        opt = torch.optim.AdamW(self.unet.model.parameters(), lr=learning_rate , betas=(0.9,0.999) , weight_decay=1e-2 , eps=1e-08)
        
        lr_scheduler = get_cosine_schedule_with_warmup(
            optimizer=opt,
            num_warmup_steps=0,
            num_training_steps=epochs *len(data_loader) ,
        )
        tempIm = None
        label__ = 0
        for epoch in range(epochs):
            errorC = 0.0
            for images ,label in data_loader:
                images= images.to(self.device)

                loss = self.trainBatch(images , label , opt ,lr_scheduler)
                errorC = errorC + loss
            train_loss = errorC / len(data_loader)
            print("epoch " + str(epoch) + " loss " + str(train_loss))
            if(epoch%generateAfterEpoch!=0):
                wandb.log({"loss": float(train_loss), "sample": wandb.Image(tempIm , caption=label__)})
            if(use_wandb):
                if(epoch%generateAfterEpoch==0):
                    num = random.randint(0,9)
                    im = self.generate(num)
                    tempIm = im
                    label__ = num
                    wandb.log({"loss": float(train_loss), "sample": wandb.Image(im , caption=label__)})
        del opt
        if(epochs == 1):
            return errorC / len(data_loader)
    def savePoint(self):
        torch.save(self.unet.state_dict(), 'prior.pth')