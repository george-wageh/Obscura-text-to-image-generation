
from torch.utils.data import DataLoader, Dataset
import os
from datasets import load_dataset
from PIL import Image

class CustomImageDataset(Dataset):
    def __init__(self):
        self.image_files = [file for file in os.listdir("/content/images") ]

    def __len__(self):
        return len(self.image_files)
    def __getitem__(self, idx):
      file_name = self.image_files[idx]
      path = "/content/images/" +  file_name
      image = Image.open(path).convert('RGB')
      return image , "fcis"



custom_dataset = CustomImageDataset()
